// Fonction pour afficher le loader
function showLoader() {
    const loader = document.querySelector('.loader');
    loader.style.display = 'block';
}

// Événement lorsque la page est entièrement chargée
window.onload = function () {
    // Vérifier si un cookie de pseudo existe
    if (!getCookie('pseudo')) {
        // Rediriger vers la page avec le formulaire d'inscription
        window.location.href = 'inscription.php';
    } else {
        // Cacher le loader une fois que la page est chargée
        const loader = document.querySelector('.loader');
        loader.style.display = 'none';

        // Retirer le flou
        const container = document.querySelector('.container');
        container.style.filter = 'none';
    }
};

// Fonction pour récupérer la valeur d'un cookie
function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    
    if (parts.length === 2) {
        return parts.pop().split(';').shift();
    }
}
