<?php
// Vérification si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["pseudo"])) {
    $pseudo = $_POST["pseudo"];

    // Informations de connexion à la base de données MySQL
    $host = "mysql1.par1.adky.net";
    $username = "u16956_Bkr2WVFRXE";
    $password = "votre_mot_de_passe";
    $database = "s16956_suno";

    // Connexion à la base de données MySQL
    $conn = new mysqli($host, $username, $password, $database);

    // Vérification de la connexion
    if ($conn->connect_error) {
        die("La connexion à la base de données a échoué : " . $conn->connect_error);
    }

    // Échappement du pseudo pour éviter les injections SQL
    $pseudo = $conn->real_escape_string($pseudo);

    // Requête SQL pour insérer le pseudo dans la base de données
    $query = "INSERT INTO pseudos (pseudo) VALUES ('$pseudo')";

    if ($conn->query($query) === TRUE) {
        // Fermeture de la connexion à la base de données
        $conn->close();

        // Redirection vers la page d'accueil ou une autre page si nécessaire
        header("Location: index.php");
        exit;
    } else {
        echo "Erreur lors de l'insertion dans la base de données : " . $conn->error;
    }

    // Fermeture de la connexion à la base de données
    $conn->close();
}
?>
