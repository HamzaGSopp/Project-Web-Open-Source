<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src="script.js"></script>
    <title>Page d'Accueil</title>
</head>
<body>
    <div class="loading-screen">
        <div class="loader"></div>
    </div>
    <div class="container">
        <div class="card">
            <h2>Card 1</h2>
            <p>Ceci est la carte 1.</p>
        </div>
        <div class="card">
            <h2>Card 2</h2>
            <p>Ceci est la carte 2.</p>
        </div>
    </div>
</body>
</html>
