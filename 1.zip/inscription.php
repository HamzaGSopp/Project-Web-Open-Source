<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="inscription.css">
    <title>Inscription</title>
</head>
<body>
    <div class="container">
        <div id="registration-form" class="registration-dialog">
            <h2>Enregistrez votre pseudo</h2>
            <form action="save_pseudo.php" method="POST" onsubmit="showLoader()">
                <input type="text" id="pseudo-input" name="pseudo" placeholder="Votre pseudo" required>
                <button type="submit">Enregistrer</button>
            </form>
        </div>
    </div>
</body>
</html>
